// === লোগো ও নামসহ কোডের ১ম অংশ ===
import 'package:flutter/material.dart';

void main() {
  runApp(const TournamentApp());
}

class TournamentApp extends StatelessWidget {
  const TournamentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Fahim Sports Live',
      theme: ThemeData(
        primarySwatch: Colors.green,
        useMaterial3: true,
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 0;

  static String teamAName = 'বাংলাদেশ';
  static String teamBName = 'ভারত';
  static int teamAScore = 0;
  static int teamBScore = 0;
  static String matchStatus = 'খেলা চলমান';

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      const RegistrationScreen(),
      LiveScoreScreen(
        teamA: teamAName,
        teamB: teamBName,
        scoreA: teamAScore.toString(),
        scoreB: teamBScore.toString(),
        status: matchStatus,
      ),
      AdminControlScreen(
        currentScoreA: teamAScore,
        currentScoreB: teamBScore,
        currentStatus: matchStatus,
        onScoreUpdated: (scoreA, scoreB, status) {
          setState(() {
            teamAScore = scoreA;
            teamBScore = scoreB;
            matchStatus = status;
          });
        },
      ),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.assignment), label: 'আবেদন ফরম'),
          BottomNavigationBarItem(icon: Icon(Icons.sports_score), label: 'লাইভ স্কোর'),
          BottomNavigationBarItem(icon: Icon(Icons.admin_panel_settings), label: 'অ্যাডমিন'),
        ],
      ),
    );
  }
}

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  String _playerName = '';
  String _playerAge = '';
  String _selectedSport = 'ফুটবল';
  String _phoneNumber = '';
  final List<String> _sports = ['ফুটবল', 'ক্রিকেট', 'ব্যাডমিন্টন', 'ক্যারম'];

  void _submitFormToServer() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('ধন্যবাদ $_playerName! তথ্য সফলভাবে পাঠানো হয়েছে।'), backgroundColor: Colors.green),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fahim Sports Live', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // কাস্টম লোগো ডিজাইন যেখানে FAHIM লেখা থাকবে
              Center(
                child: Column(
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        const Icon(Icons.emoji_events, size: 90, color: Colors.orange), // ট্রফি আইকন
                        Positioned(
                          top: 25,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(color: Colors.black.withOpacity(0.7), borderRadius: BorderRadius.circular(4)),
                            child: const Text(
                              'FAHIM',
                              style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    const Text('খেলায় অংশগ্রহণের অনলাইন আবেদন', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey)),
                  ],
                ),
              ),
              const SizedBox(height: 25),
              TextFormField(
                decoration: const InputDecoration(labelText: 'খেলোয়াড়ের সম্পূর্ণ নাম', border: OutlineInputBorder()),
                validator: (value) => (value == null || value.isEmpty) ? 'নাম লিখুন' : null,
                onSaved: (value) => _playerName = value!,
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(labelText: 'বয়স', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                validator: (value) => (value == null || value.isEmpty) ? 'বয়স লিখুন' : null,
                onSaved: (value) => _playerAge = value!,
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(labelText: 'মোবাইল নম্বর', border: OutlineInputBorder()),
                keyboardType: TextInputType.phone,
                validator: (value) => (value == null || value.isEmpty) ? 'নম্বর লিখুন' : null,
                onSaved: (value) => _phoneNumber = value!,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selectedSport,
                decoration: const InputDecoration(labelText: 'খেলার ধরণ নির্ধারণ করুন', border: OutlineInputBorder()),
                items: _sports.map((sport) => DropdownMenuItem(value: sport, child: Text(sport))).toList(),
                onChanged: (value) => setState(() => _selectedSport = value!),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: _submitFormToServer, 
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(vertical: 14)), 
                child: const Text('সার্ভারে জমা দিন', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))
              ),
            ],
          ),
        ),
      ),
    );
  }
}
// === লোগো ও নামসহ কোডের ২য় অংশ (১৯২ নম্বর লাইনে পেস্ট করুন) ===
class LiveScoreScreen extends StatelessWidget {
  final String teamA;
  final String teamB;
  final String scoreA;
  final String scoreB;
  final String status;

  const LiveScoreScreen({
    super.key,
    required this.teamA,
    required this.teamB,
    required this.scoreA,
    required this.scoreB,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fahim Sports Live', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), backgroundColor: Colors.green, centerTitle: true),
      backgroundColor: Colors.grey[200],
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // লাইভ স্কোর পেজেও কাস্টম লোগো দেখা যাবে
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.emoji_events, size: 40, color: Colors.orange),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.8), borderRadius: BorderRadius.circular(4)),
                    child: const Text('FAHIM APP', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.sports_soccer, color: Colors.green),
                        const SizedBox(width: 8),
                        const Text('লাইভ ম্যাচ', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
                        const Spacer(),
                        Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(12)), child: const Text('LIVE', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold))),
                      ],
                    ),
                    const Divider(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(children: [Text(teamA, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(scoreA, style: const TextStyle(fontSize: 28, color: Colors.green, fontWeight: FontWeight.bold))]),
                        const Text('VS', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red)),
                        Column(children: [Text(teamB, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(scoreB, style: const TextStyle(fontSize: 28, color: Colors.green, fontWeight: FontWeight.bold))]),
                      ],
                    ),
                    const Divider(height: 24),
                    Text(status, style: const TextStyle(color: Colors.blue, fontSize: 16, fontWeight: FontWeight.w500)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AdminControlScreen extends StatefulWidget {
  final int currentScoreA;
  final int currentScoreB;
  final String currentStatus;
  final Function(int, int, String) onScoreUpdated;

  const AdminControlScreen({
    super.key,
    required this.currentScoreA,
    required this.currentScoreB,
    required this.currentStatus,
    required this.onScoreUpdated,
  });

  @override
  State<AdminControlScreen> createState() => _AdminControlScreenState();
}

class _AdminControlScreenState extends State<AdminControlScreen> {
  late int scoreA;
  late int scoreB;
  final _statusController = TextEditingController();

  @override
  void initState() {
    super.initState();
    scoreA = widget.currentScoreA;
    scoreB = widget.currentScoreB;
    _statusController.text = widget.currentStatus;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('অ্যাডমিন কন্ট্রোল', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), backgroundColor: Colors.green, centerTitle: true),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('লাইভ স্কোর পরিবর্তন প্যানেল', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    const Text('টিম এ'),
                    Row(children: [
                      IconButton(icon: const Icon(Icons.remove_circle, color: Colors.red), onPressed: () => setState(() => scoreA > 0 ? scoreA-- : null)),
                      Text('$scoreA', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                      IconButton(icon: const Icon(Icons.add_circle, color: Colors.green), onPressed: () => setState(() => scoreA++)),
                    ]),
                  ],
                ),
                Column(
                  children: [
                    const Text('টিম বি'),
                    Row(children: [
                      IconButton(icon: const Icon(Icons.remove_circle, color: Colors.red), onPressed: () => setState(() => scoreB > 0 ? scoreB-- : null)),
                      Text('$scoreB', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                      IconButton(icon: const Icon(Icons.add_circle, color: Colors.green), onPressed: () => setState(() => scoreB++)),
                    ]),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            TextField(controller: _statusController, decoration: const InputDecoration(labelText: 'ম্যাচ স্ট্যাটাস পরিবর্তন করুন', border: OutlineInputBorder())),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                widget.onScoreUpdated(scoreA, scoreB, _statusController.text);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সার্ভার স্কোর লাইভ আপডেট সফল!'), backgroundColor: Colors.blue));
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text('স্কোর লাইভ আপডেট করুন', style: TextStyle(fontSize: 16, color: Colors.white)),
            )
          ],
        ),
      ),
    );
  }
}
